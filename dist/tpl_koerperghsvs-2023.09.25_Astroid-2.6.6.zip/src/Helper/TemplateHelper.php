<?php
namespace GHSVS\Template\KoerperGhsvs\Site\Helper;

\defined('_JEXEC') or die;

abstract class TemplateHelper
{
  public static function Test() {
    return 'Test';
  }
}
