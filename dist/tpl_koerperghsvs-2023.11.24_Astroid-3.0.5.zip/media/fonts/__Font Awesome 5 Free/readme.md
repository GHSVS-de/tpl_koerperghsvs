Passend zu scss\custom\_joomla-fontawesome-custom.scss
