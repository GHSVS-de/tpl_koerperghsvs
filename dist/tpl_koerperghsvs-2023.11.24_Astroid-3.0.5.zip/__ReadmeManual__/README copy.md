# Zu installieren

## FILE_ASSETGHSVS/PKG_ASSETGHSVS

## Template koerperghsvs

## Phoca Top Menu

## SplideJsGhsvs slider

## System - bs3GHSVS (????)

## System - Hyphenateghsvs

## System - ImportFonts by GHSVS.de

# Icon-Fonts
- Verwendet hart einkodiert und im Template abgelegten "Font Awesome 5 Free".
  - `media\templates\site\koerperghsvs\fonts\`
- Verwendet dazu passend hart einkodiert `joomla-fontawesome.css` aus Joomla 4.3.4, so, dass auch die icon-xyz-Klassen verwendet werden können.
  - `media\templates\site\koerperghsvs\scss\custom\_joomla-fontawesome-custom.scss`

# Favicons
- Erstellen Sie sich anhand der Anleitung dort mit dem Tool https://realfavicongenerator.net/ ein Favicon-Paket.
- Entpacken Sie das heruntergeladene ZIP-Archiv und kopieren Sie ALLE Bilder und Dateien darin per FTP in das Stammverzeichnis Ihres Joomlas.
- So sollte der Ordnerinhalt aussehen: Siehe Bild favicon-dateien.jpg
